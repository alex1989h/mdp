function gv = Gravitation(x)
G = 66.743*(10^(-12))
me = 5.9736*(10^24)
re = 6378
e = x/(-norm(x))
gv = G*(me/(re*re))*e
end